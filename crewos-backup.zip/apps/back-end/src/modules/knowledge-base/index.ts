export { router as knowledge_baseRouter } from "./knowledge-base.routes.js";
