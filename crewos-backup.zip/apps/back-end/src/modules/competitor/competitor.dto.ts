
// All domain types have been moved to @mh-os/shared. Only UI/View/Props types may remain here.

// Phase-B: Competitor DTO stubs
export type GetCompetitorPricesInput = any;
export type ScanCompetitorsInput = any;
export type CompetitorPriceRecord = any;
export type ScanResult = any;
