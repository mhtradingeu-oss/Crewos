// TODO: expose service & DTO helpers as the feature evolves.
export { router as competitorRouter } from "./competitor.routes.js";
