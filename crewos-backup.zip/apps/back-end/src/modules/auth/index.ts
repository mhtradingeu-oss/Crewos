export { default as authRouter } from "./auth.routes.js";
