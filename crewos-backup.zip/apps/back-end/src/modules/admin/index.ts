export { router as adminRouter } from "./admin.routes.js";
