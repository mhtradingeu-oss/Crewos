export { router as brandRouter } from "./brand.routes.js";
