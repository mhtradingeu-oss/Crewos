export { router as mediaStudioRouter } from "./media-studio.routes.js";
