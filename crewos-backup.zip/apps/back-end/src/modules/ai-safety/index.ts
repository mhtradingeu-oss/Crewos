export { router as aiSafetyRouter } from "./ai-safety.routes.js";
