export { router as inventoryRouter } from "./inventory.routes.js";
