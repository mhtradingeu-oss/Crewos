export { router as communicationRouter } from "./communication.routes.js";
