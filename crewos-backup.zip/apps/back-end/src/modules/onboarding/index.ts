export { default as onboardingRouter } from "./onboarding.routes.js";
