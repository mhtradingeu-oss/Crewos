export { router as loyaltyRouter } from "./loyalty.routes.js";
