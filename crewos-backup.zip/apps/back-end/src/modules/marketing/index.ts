export { router as marketingRouter } from "./marketing.routes.js";
