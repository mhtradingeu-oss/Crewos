export { router as dealersRouter } from "./dealers.routes.js";
