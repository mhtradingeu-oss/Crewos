export { router as crmRouter } from "./crm.routes.js";
