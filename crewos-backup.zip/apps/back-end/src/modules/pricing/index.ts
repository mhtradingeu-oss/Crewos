export { router as pricingRouter } from "./pricing.routes.js";
