export { router as affiliateRouter } from "./affiliate.routes.js";
