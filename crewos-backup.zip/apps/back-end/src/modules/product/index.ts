export { router as productRouter } from "./product.routes.js";
