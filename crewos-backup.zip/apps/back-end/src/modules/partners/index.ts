export { router as partnersRouter } from "./partners.routes.js";
