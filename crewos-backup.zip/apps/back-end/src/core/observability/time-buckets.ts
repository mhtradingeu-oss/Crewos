// Time bucket helpers for Automation Observability
// Strictly read-only. See system prompt for architectural constraints.

export {};
